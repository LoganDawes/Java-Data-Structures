1. How to Run The Program:
   
   My file name is Assignment05.java.

compile the file as: javac Assignment05.java

which will then produce .class files Assignment05.class, Graph.class, etc. for all .java files required.

run the program using: java Assignment05

program will prompt user to input the name of the input file.

2. CSX Server Tested On:
   
   ssh ldawes@csx1.cs.okstate.edu

3. Assumptions Made:
   - The program is being run with all of the .java files in the same directory
   - The program is being run with the input file in the same directory
   - The program assumes the input is provided via standard input.
   - It has been tested using Java version 17.